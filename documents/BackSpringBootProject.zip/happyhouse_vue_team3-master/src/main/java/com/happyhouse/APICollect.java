package com.happyhouse;

import java.util.TimerTask;

public class APICollect extends TimerTask {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
