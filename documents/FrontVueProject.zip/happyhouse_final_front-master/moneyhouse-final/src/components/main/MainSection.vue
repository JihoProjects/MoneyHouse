<template>
    <section class="my-3 py-3">
        <b-container>
            <b-row>
                <b-col align-self="center">
                    <h1 class="my-3">내 집 마련하기</h1>
                    <h3>
                        실패를 피하는 가장 확실한 방법은<br>
                        <strong>철저한 공부</strong>입니다.
                    </h3>
                </b-col>
                <b-col>
                    <b-icon-check2-all variant="danger" class="mx-2" scale="1"></b-icon-check2-all><span>매일 부를 키우는 부자 공부법</span><br>
                    <b-icon-check2-all variant="danger" class="mx-2" scale="1"></b-icon-check2-all><span>1. 하루 1시간 부자 수업</span><br>
                    <b-icon-check2-all variant="danger" class="mx-2" scale="1"></b-icon-check2-all><span>2. 투자 안목을 길러주는 ‘일일삼방’</span><br>
                    <p class="my-4">
                        <i>
                            "실전 투자보다 더 나은 공부는 없다" 지금까지 부자 공부법에 대해 말씀드렸는데요.
                            소개해드린 방식대로 공부하신다면 이론은 충분하실 거라 생각합니다.
                            여기서 잠깐! 이론만 공부했다고 자신의 미래에 대한 책임을 다 한 걸까요?
                            아닙니다. 실전 투자보다 더 나은 공부는 없습니다.
                            게다가 부동산은 물가에 연동해서 우상향하는 성향이 있습니다.
                            결국 누가 먼저 시작하느냐의 싸움이죠.
                        </i>
                    </p>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>

<script>
export default {

}
</script>

<style scope>
.col h1 {
    font-family: 'Black Han Sans';
}
.col h3 {
    font-family: 'Franklin Gothic Medium';
}
</style>
